// priority: 0

console.info('Hello, World! (You will see this line every time server resources reload)')

let MC = (id) => `minecraft:${id}`
let PrE = (id) => `projecte:${id}`
let PrEx = (id) => `projectexpansion:${id}`
let MA = (id) => `mysticalagriculture:${id}`
let ATO = (id) => `alltheores:${id}`
let TE = (id) => `thermal:${id}`
let SD = (id) => `storagedrawers:${id}`

ServerEvents.recipes(event => {
	// Project E
	event.remove({ output: PrE('philosophers_stone') });
	event.shaped(PrE('philosophers_stone'),
	[
		'ABA',
		'BCB',
		'ABA'
	],
	{
		A: MC('redstone_block'),
		B: MC('glowstone'),
		C: MC('nether_star')
	});

	event.shaped(PrE('philosophers_stone'),
	[
		'BAB',
		'ACA',
		'BAB'
	],
	{
		A: MC('redstone_block'),
		B: MC('glowstone'),
		C: MC('nether_star')
	});

	event.remove({ output: PrE('soul_stone') });
	event.remove({ output: PrE('swiftwolf_rending_gale') });
	event.remove({ output: PrE('rm_katar') });
	event.remove({ output: PrE('rm_morning_star') });

	['1', '2', '3'].forEach(num => {	
		event.remove({ output: PrE(`relay_mk${num}`) });
		event.remove({ output: PrE(`collector_mk${num}`) });	
	});

	['pick', 'axe', 'shovel', 'sword', 'hoe', 'shears', 'hammer'].forEach(num => {
		event.remove({ output:  PrE(`dm_${num}`) });
		event.remove({ output:  PrE(`rm_${num}`) });
	});
	
	['helmet', 'chestplate', 'leggings', 'boots'].forEach(num => {
		event.remove({ output:  PrE(`dm_${num}`) });
		event.remove({ output:  PrE(`rm_${num}`) });
		event.remove({ output:  PrE(`gem_${num}`) });
	});


	// Project Expansion
	/*
	event.remove({ id: '/projectexpansion:power_flower/' });
	event.remove({ id: '/projectexpansion:collector/' });
	event.remove({ id: '/projectexpansion:relay/' });
	*/

	event.remove({ id: PrEx('matter_upgrader_2') });

	['1', '2', '3'].forEach(num => {
		event.remove({ id: PrEx(`collector/mk${num}_conversion`) });
		event.remove({ id: PrEx(`relay/mk${num}_conversion`) });
	});
	

	// Mystical Agriculture
	// Infusions
	event.remove({ id: MA('seed/infusion/rubber') });
	event.remove({ id: MA('seed/infusion/apatite') });
	event.remove({ id: MA('seed/infusion/tin') });
	event.remove({ id: MA('seed/infusion/bronze') });
	event.remove({ id: MA('seed/infusion/graphite') });
	event.remove({ id: MA('seed/infusion/invar') });
	event.remove({ id: MA('seed/infusion/mithril') });
	event.remove({ id: MA('seed/infusion/tungsten') });
	event.remove({ id: MA('seed/infusion/titanium') });
	event.remove({ id: MA('seed/infusion/chrome') });
	event.remove({ id: MA('seed/infusion/ruby') });
	event.remove({ id: MA('seed/infusion/sapphire') });
	event.remove({ id: MA('seed/infusion/platinum') });
	event.remove({ id: MA('seed/infusion/iridium') });
	// Reprocessor
	event.remove({ id: MA('seed/reprocessor/rubber') });
	event.remove({ id: MA('seed/reprocessor/apatite') });
	event.remove({ id: MA('seed/reprocessor/tin') });
	event.remove({ id: MA('seed/reprocessor/bronze') });
	event.remove({ id: MA('seed/reprocessor/graphite') });
	event.remove({ id: MA('seed/reprocessor/invar') });
	event.remove({ id: MA('seed/reprocessor/mithril') });
	event.remove({ id: MA('seed/reprocessor/tungsten') });
	event.remove({ id: MA('seed/reprocessor/titanium') });
	event.remove({ id: MA('seed/reprocessor/chrome') });
	event.remove({ id: MA('seed/reprocessor/ruby') });
	event.remove({ id: MA('seed/reprocessor/sapphire') });
	event.remove({ id: MA('seed/reprocessor/platinum') });
	event.remove({ id: MA('seed/reprocessor/iridium') });

	// Thermal Expansion
	event.remove({ id: '/thermal:augments/' });
	event.remove({ output: TE('wrench') });
	event.remove({ output: TE('redprint') });
	event.remove({ output: TE('redstone_servo') });

	['1', '2', '3'].forEach(num => {
		event.remove({ output: TE(`upgrade_augment_${num}`) });
	});

	['invar', 'bronze'].forEach(item => {
		event.remove({ output: TE(`${item}_ingot`) });
		event.remove({ output: TE(`${item}_nugget`) });
		event.remove({ output: TE(`${item}_dust`) });
		event.remove({ output: TE(`${item}_gear`) });
	});

	// Storage Drawers
	['obsidian', 'diamond', 'emerald'].forEach(item => {
		event.remove({ output: SD(`${item}_storage_upgrade`)});
	});
	
	// Drawer Upgrade Replace Helper Function
	let drawerUpgrades = (output, upgradeMaterial) => {
		event.shaped(output, [
			'AAA',
			'BCB',
			'AAA'
		],
		{
			A: '#forge:rods/wooden',
			B: upgradeMaterial,
			C: SD('upgrade_template')
		});
	};
	
	drawerUpgrades( SD('obsidian_storage_upgrade'), MC('copper_ingot') );
	drawerUpgrades( SD('diamond_storage_upgrade'), MC('obsidian') );
	drawerUpgrades( SD('emerald_storage_upgrade'), MC('diamond') );

});

ServerEvents.tags('item', event => {
	// Get the #forge:cobblestone tag collection and add Diamond Ore to it
	// event.get('forge:cobblestone').add('minecraft:diamond_ore')

	// Get the #forge:cobblestone tag collection and remove Mossy Cobblestone from it
	// event.get('forge:cobblestone').remove('minecraft:mossy_cobblestone')
})
