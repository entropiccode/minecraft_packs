// priority: 0

console.info('Hello, World! (You will see this line every time client resources reload)')

let MC = (id) => `minecraft:${id}`
let PrE = (id) => `projecte:${id}`
let PrEx = (id) => `projectexpansion:${id}`
let MA = (id) => `mysticalagriculture:${id}`
let AE2 = (id) => `ae2:${id}`
let IE = (id) => `immersiveengineering:${id}`
let TE = (id) => `thermal:${id}`

JEIEvents.hideItems(event => {
	// Hide items in JEI here

	// ProjectE
	event.hide( PrE('life_stone') );
	event.hide( PrE('soul_stone') );
	event.hide( PrE('rm_katar') );
	event.hide( PrE('rm_morning_star') );
	event.hide( PrE('swiftwolf_rending_gale') );

	['1', '2', '3'].forEach(num => {	
		event.hide( PrE(`relay_mk${num}`) );
		event.hide( PrE(`collector_mk${num}`) );	
	});

	['pick', 'axe', 'shovel', 'sword', 'hoe', 'shears', 'hammer'].forEach(num => {
		event.hide( PrE(`dm_${num}`) );
		event.hide( PrE(`rm_${num}`) );
	});
	
	['helmet', 'chestplate', 'leggings', 'boots'].forEach(num => {
		event.hide( PrE(`dm_${num}`) );
		event.hide( PrE(`rm_${num}`) );
		event.hide( PrE(`gem_${num}`) );
	});

	/*
	// Project Expansion
	event.hide( PrEx('matter_upgrader') );

	
	['basic', 'dark', 'red', 'magenta', 'pink', 'purple', 'violet', 'blue', 'cyan', 'green', 'lime', 'yellow', 'orange', 'white', 'fading', 'final']
	.forEach(num => {	
		event.hide( PrEx(`${num}_power_flower`) );
		event.hide( PrEx(`${num}_collector`) );
		event.hide( PrEx(`${num}_compressed_collector`) );
		event.hide( PrEx(`${num}_relay`) );
	});
	*/

	// Mystical Agriculture
	event.hide( MA('inferium_ore') );
	event.hide( MA('deepslate_inferium_ore') );
	event.hide( MA('rubber_seeds') );
	event.hide( MA('apatite_seeds') );
	event.hide( MA('tin_seeds') );
	event.hide( MA('bronze_seeds') );
	event.hide( MA('graphite_seeds') );
	event.hide( MA('invar_seeds') );
	event.hide( MA('mithril_seeds') );
	event.hide( MA('tungsten_seeds') );
	event.hide( MA('titanium_seeds') );
	event.hide( MA('chrome_seeds') );
	event.hide( MA('ruby_seeds') );
	event.hide( MA('sapphire_seeds') );
	event.hide( MA('platinum_seeds') );
	event.hide( MA('iridium_seeds') );
	event.hide( MA('rubber_essence') );
	event.hide( MA('apatite_essence') );
	event.hide( MA('tin_essence') );
	event.hide( MA('bronze_essence') );
	event.hide( MA('graphite_essence') );
	event.hide( MA('invar_essence') );
	event.hide( MA('mithril_essence') );
	event.hide( MA('tungsten_essence') );
	event.hide( MA('titanium_essence') );
	event.hide( MA('chrome_essence') );
	event.hide( MA('ruby_essence') );
	event.hide( MA('sapphire_essence') );
	event.hide( MA('platinum_essence') );
	event.hide( MA('iridium_essence') );

	// Applied Energistics 2
	event.hide( AE2('facade') );

	// Thermal Expansion
	event.hide( TE('wrench') );
	event.hide( TE('redprint') );
	event.hide( TE('redstone_servo') );

	['xp_storage', 'rf_coil', 'rf_coil_storage', 'rf_coil_xfer', 'rf_coil_creative', 'fluid_tank', 'fluid_tank_creative', 'item_filter', 'fluid_filter'].forEach(item => {
		event.hide( TE(`${item}_augment`) );
	});

	['1', '2', '3'].forEach(num => {
		event.hide( TE(`upgrade_augment_${num}`) );
	});

	['invar', 'bronze'].forEach(item => {
		event.hide( TE(`${item}_ingot`) );
		event.hide( TE(`${item}_nugget`) );
		event.hide( TE(`${item}_dust`) );
		event.hide( TE(`${item}_gear`) );
	});

	// Immersive Engineering
	event.hide( IE('nugget_copper') );

	['saltpeter', 'sulfur', 'wood', 'copper', 'lead', 'silver', 'nickel', 'constantan', 'electrum', 'iron', 'gold'].forEach(item => {
		event.hide( IE(`dust_${item}`) );
	});
	
	['lead', 'silver', 'nickel', 'electrum', 'constantan'].forEach(item => {
		event.hide( IE(`ingot_${item}`) );
		event.hide( IE(`nugget_${item}`) );
	});

	['lead', 'silver', 'nickel'].forEach(item => {
		event.hide( IE(`raw_${item}`) );
	});
})
